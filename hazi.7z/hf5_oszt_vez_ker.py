import math
t = list(map(lambda x: list(map(int, x.split("."))),open("input (4).txt").read().split("\n")))
def masodik():
    
    lis = []
    for i in t[1]:
        if i % 3 == 0:
            lis.append(i)
    return(min(lis))
print(masodik())

def elso():

    lis = []
    while len(lis) != 15:
        lis.append(min(t[0]))
        t[0].remove(min(t[0]))
    
    return sum(lis) /15




def harmadik():

    lis = []
    while len(lis) != 12:
        lis.append(min(t[2]))
        t[2].remove(min(t[2]))

    print(lis)
    return sum(lis) 


def negyedik():

    lis = []

    for i in t[3]:
        if i < 5:
            lis.append(i)
    szorzat = 1
    for x in lis:
        szorzat *= x

    return math.log(szorzat)

def otodik():

    lis = []

    for i in t[4]:
        if i% 2 == 1:
            lis.append(i)
    return max(lis)

def hatodik():

    lis = []

    for i in t:
        for j in i:
            if j % 2 == 0:
                lis.append(j**2)
            
    return sum(lis)



print(f"Az 1. sorban szereplő 19-nél kisebb számok maximuma: {elso()}")
print(f"A  2. sorban szereplő 10 legnagyobb szám négyzeteinek összege: {masodik()}")
print(f"A  3. sorban szereplő páros számok számtani közepe: {harmadik()}")
print(f"A  4. sorban szereplő 15 legkisebb szám minimuma: {negyedik()}")
print(f"Az 5. sorban szereplő hárommal osztható számok szorzatának nagyságrendje: 10^{otodik()}")
print(f"Az inputban szereplő összes szám közül a 12 legkisebb szám összege: {hatodik()}")




       


    
        
    


    

    
